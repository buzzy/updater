import { CapacitorUpdater } from "@capgo/capacitor-updater";

CapacitorUpdater.notifyAppReady();

alert("Hello from version 1!!");
